# from flask import Flask, render_template, request, jsonify
# import pandas as pd
# import requests
# import folium
# from weather_converter import get_weather

# app = Flask(__name__)

# API_KEY = '70914c972c7f43b99e0646ab7eeae9bf'  # Replace with your OpenCage API key

# # Load Excel dataset and ensure we use the correct header
# def load_dataset():
#     file_path = 'dataset.xlsx'
#     df = pd.read_excel(file_path, header=0)  # Set the first row as header
#     return df

# def get_lat_lon(address):
#     """Fetch latitude and longitude for a given address using the OpenCage API."""
#     url = f'https://api.opencagedata.com/geocode/v1/json?q={address}&key={API_KEY}'
#     response = requests.get(url)
#     data = response.json()
#     if data['results']:
#         lat = data['results'][0]['geometry']['lat']
#         lon = data['results'][0]['geometry']['lng']
#         return lat, lon
#     else:
#         return None, None

# def preprocess_data(df):
#     """Preprocess the DataFrame: replace nulls with '0' and skip rows with '0' address."""
#     df.fillna('0', inplace=True)
#     address_column = 'Address'  # Your dataset contains this column for addresses
#     df = df[df[address_column] != '0'].copy()  # Keep rows where address is valid
#     return df

# def generate_map(df):
#     """Generate a folium map with markers for the addresses."""
#     df = preprocess_data(df)

#     # Ensure Latitude and Longitude columns exist
#     if 'Latitude' not in df.columns or 'Longitude' not in df.columns:
#         df['Latitude'] = None
#         df['Longitude'] = None
#     updated = False
#     for i, row in df.iterrows():
#         if pd.isna(row['Latitude']) or pd.isna(row['Longitude']):
#             lat, lon = get_lat_lon(row['Address'])
#             # weather=get_weather(lat,lon)
#             df.at[i, 'Latitude'] = lat
#             df.at[i, 'Longitude'] = lon
#             # print(weather)
#             updated = True
#     if updated:
#         df.to_excel('dataset.xlsx', index=False)
#     df['Latitude'] = pd.to_numeric(df['Latitude'], errors='coerce')
#     df['Longitude'] = pd.to_numeric(df['Longitude'], errors='coerce')
#     df.dropna(subset=['Latitude', 'Longitude'], inplace=True)
#     if not df.empty:
#         average_lat = df['Latitude'].mean()
#         average_lon = df['Longitude'].mean()
#     else:
#         average_lat, average_lon = 0, 0
#     mymap = folium.Map(location=[average_lat, average_lon], zoom_start=4)
#     for _, row in df.iterrows():
#         popup_html = f"""
#         <div>
#             <strong>{row['Name']}</strong><br>
#             <button onclick=updateDetailsTable('{row.get('Firm Name')}', '{row.get('Department')}', '{row.get('Type of Entity')}', '{row['Address']}', '{row.get('Client e-mail')}', '{row.get('Contact Name')}', '{row.get('Contact No.')}', '{row.get('Airport Name')}', '{row.get('Airport Address')}', '{row.get('Nearest Hotel')}', '{row.get('FO Reporting')}')">Show Details</button>
#         </div>
#         """
#         folium.Marker(
#             location=[row['Latitude'], row['Longitude']],
#             popup=popup_html
#         ).add_to(mymap)

#     # Save the map as an HTML file
#     map_path = 'static/map_with_markers.html'
#     mymap.save(map_path)
#     return map_path

# @app.route('/')
# def index():
#     """Home page that displays the map and filter form."""
#     df = load_dataset()  # Load the dataset with proper headers
#     generate_map(df)
#     return render_template('map.html')

# @app.route('/filter', methods=['POST'])
# def filter_map():
#     """Apply filters to the data and regenerate the map."""
#     client = request.json.get('client')
#     state = request.json.get('state')
#     department = request.json.get('department')

#     df = load_dataset()
#     if client and client != 'ALL':
#         df = df[df['References'] == client]
#     if state and state != 'ALL':
#         df = df[df['State'] == state]
#     if department and department != 'ALL':
#         df = df[df['Department'] == department]
#     # Regenerate the map with filtered data
#     generate_map(df)
#     return jsonify(success=True)

# if __name__ == '__main__':
#     app.run(debug=False)








from flask import Flask, render_template, request, jsonify
import pandas as pd
import requests
import folium
from weather_converter import get_weather

app = Flask(__name__)

API_KEY = '70914c972c7f43b99e0646ab7eeae9bf'  # Replace with your OpenCage API key

# Load Excel dataset and ensure we use the correct header
def load_dataset():
    file_path = 'dataset.xlsx'
    df = pd.read_excel(file_path, header=0)  # Set the first row as header
    return df

def get_lat_lon(address):
    """Fetch latitude and longitude for a given address using the OpenCage API."""
    url = f'https://api.opencagedata.com/geocode/v1/json?q={address}&key={API_KEY}'
    response = requests.get(url)
    data = response.json()
    if data['results']:
        lat = data['results'][0]['geometry']['lat']
        lon = data['results'][0]['geometry']['lng']
        return lat, lon
    else:
        return None, None

def preprocess_data(df):
    """Preprocess the DataFrame: replace nulls with '0' and skip rows with '0' address."""
    df.fillna('0', inplace=True)
    address_column = 'Address'  # Your dataset contains this column for addresses
    df = df[df[address_column] != '0'].copy()  # Keep rows where address is valid
    return df

def generate_map(df):
    """Generate a folium map with markers for the addresses."""
    df = preprocess_data(df)

    # Ensure Latitude and Longitude columns exist
    if 'Latitude' not in df.columns or 'Longitude' not in df.columns:
        df['Latitude'] = None
        df['Longitude'] = None
    updated = False
    for i, row in df.iterrows():
        if pd.isna(row['Latitude']) or pd.isna(row['Longitude']):
            lat, lon = get_lat_lon(row['Address'])
            df.at[i, 'Latitude'] = lat
            df.at[i, 'Longitude'] = lon
            updated = True
    if updated:
        df.to_excel('dataset.xlsx', index=False)
    df['Latitude'] = pd.to_numeric(df['Latitude'], errors='coerce')
    df['Longitude'] = pd.to_numeric(df['Longitude'], errors='coerce')
    df.dropna(subset=['Latitude', 'Longitude'], inplace=True)
    if not df.empty:
        average_lat = df['Latitude'].mean()
        average_lon = df['Longitude'].mean()
    else:
        average_lat, average_lon = 0, 0
    mymap = folium.Map(location=[average_lat, average_lon], zoom_start=4)

    # Add markers for each row
    for _, row in df.iterrows():
        folium.Marker(
            location=[row['Latitude'], row['Longitude']],
            popup=f"<button onclick=\"fetchDetails({row['Latitude']}, {row['Longitude']})\">Show Details</button>"
        ).add_to(mymap)

    # Save the map as an HTML file
    map_path = 'static/map_with_markers.html'
    mymap.save(map_path)
    return map_path

@app.route('/')
def index():
    """Home page that displays the map and filter form."""
    df = load_dataset()  # Load the dataset with proper headers
    generate_map(df)
    return render_template('map.html')

@app.route('/get_details', methods=['POST'])
def get_details():
    """Fetch the location details based on latitude and longitude."""
    lat = request.json.get('latitude')
    lon = request.json.get('longitude')

    # Load dataset
    df = load_dataset()

    # Find the row with matching lat/lon
    location = df[(df['Latitude'] == lat) & (df['Longitude'] == lon)]

    if not location.empty:
        # Return the details as a dictionary
        location_data = location.iloc[0].to_dict()
        return jsonify({'status': 'success', 'data': location_data})
    else:
        return jsonify({'status': 'error', 'message': 'No data found for the given coordinates'})

if __name__ == '__main__':
    app.run(debug=False)

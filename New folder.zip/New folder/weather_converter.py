import requests

weather_api = '392bf9b1ef37ca9d75da2f0e5099813c'  # OpenWeatherMap APIs

def get_weather(lat, lon):
    """Fetch weather based on latitude and longitude."""
    url = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={weather_api_key}&units=metric"
    response = requests.get(url)
    data = response.json()
    if response.status_code == 200:
        weather_description = data['weather'][0]['description']
        temperature = data['main']['temp']
        return {
            'weather': weather_description,
            'temperature': temperature
        }
    else:
        return None

def get_weather_for_city(city_name):
    """Fetch weather for a specific city."""
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={weather_api}&units=metric"
    response = requests.get(url)
    data = response.json()
    if response.status_code == 200:
        return {
            'name': city_name,
            'temp': data['main']['temp'],
            'icon': data['weather'][0]['icon'],
            'description': data['weather'][0]['description']
        }
    else:
        return None

def get_weather_for_cities(cities):
    """Fetch weather data for multiple cities."""
    weather_data = []
    for city in cities:
        city_weather = get_weather_for_city(city)
        if city_weather:
            weather_data.append(city_weather)
    return weather_data

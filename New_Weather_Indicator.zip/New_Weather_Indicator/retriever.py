# import pandas as pd
# def data_retriever(add):
#     df=pd.read_excel("dataset.xlsx")
#     matching_row = df[(df['Address'] == add)]
#     # print(matching_row)
#     if matching_row is not None:
#         # print(matching_row)
#         return matching_row
#     else:
#         # return "No match found for the provided latitude and longitude."
#         return "No match found for the provided address."
# # print(data_retriever("522 Grand Ave, Oakland, CA 94610"))





import pandas as pd

def data_retriever(add):
    # Load the Excel dataset
    df = pd.read_excel("dataset.xlsx")
    
    # Clean the Address column in the DataFrame
    df['Address'] = df['Address'].astype(str).str.strip().str.lower()
    
    # Clean the input address (add)
    add_clean = str(add).strip().toLowerCase()
    
    # Print statements to verify the addresses being compared
    print(f"Cleaned input address: {add_clean}")
    print("Sample cleaned addresses from the dataset:")
    print(df['Address'].head())  # Print the first few addresses for verification
    
    # Search for a matching address in the cleaned DataFrame
    matching_row = df[df['Address'] == add_clean]
    
    # Check if any matching row was found
    if not matching_row.empty:
        print("Matching row found:", matching_row)
        return matching_row
    else:
        print("No match found for the provided address.")
        return None
